-- ==========================================
-- DATABASE SELECTION 
-- ==========================================
USE retail_analysis;

-- ==========================================
--  1. TABLE STRUCTURE
-- Check columns, data types and NULL settings
-- ==========================================
DESCRIBE retail_sales_master;

-- ==========================================
-- 2. TOTAL RECORD COUNT
-- Check total number of records in the dataset
-- ==========================================
SELECT COUNT(*) AS Total_Rows
FROM retail_sales_master;

-- ==========================================
-- 3. SAMPLE DATA CHECK
-- Preview the first 10 records
-- ==========================================
SELECT *
FROM retail_sales_master
LIMIT 10;

-- ==========================================
-- 4. DATA QUALITY - NULL VALUE CHECK
-- Check missing values in all important columns
-- ==========================================
SELECT
    SUM(Productid IS NULL) AS Productid_NULL,
    SUM(OrderId IS NULL) AS OrderId_NULL,
    SUM(SaleDate IS NULL) AS SaleDate_NULL,
    SUM(Store IS NULL) AS Store_NULL,
    SUM(Region IS NULL) AS Region_NULL,
    SUM(ProductCategory IS NULL) AS ProductCategory_NULL,
    SUM(Occasion IS NULL) AS Occasion_NULL,
    SUM(Material IS NULL) AS Material_NULL,
    SUM(UnitsSold IS NULL) AS UnitsSold_NULL,
    SUM(Revenue IS NULL) AS Revenue_NULL,
    SUM(Weighted_Average_Cost IS NULL) AS Weighted_Cost_NULL
FROM retail_sales_master;

-- ==========================================
-- 5. DATA QUALITY - DUPLICATE CHECK
-- Check for duplicate Order ID
-- ==========================================
SELECT
    OrderId,
    COUNT(*) AS Duplicate_Count
FROM retail_sales_master
GROUP BY OrderId
HAVING COUNT(*) > 1;

-- ==========================================
-- 6. DATE RANGE ANALYSIS
-- Identify earliest and latest sales dates
-- ==========================================
SELECT
    MIN(STR_TO_DATE(SaleDate, '%Y-%m-%d')) AS Earliest_Date,
    MAX(STR_TO_DATE(SaleDate, '%Y-%m-%d')) AS Latest_Date,
    COUNT(*) AS Total_Records
FROM retail_sales_master;

-- ==========================================
-- 7. NUMERICAL DATA VALIDATION
-- Check minimum, maximum, negative and zero values
-- for Revenue and Units Sold
-- ==========================================
SELECT
    MIN(Revenue) AS Minimum_Revenue,
    MAX(Revenue) AS Maximum_Revenue,
    SUM(CASE WHEN Revenue < 0 THEN 1 ELSE 0 END) AS Negative_Revenue,
    SUM(CASE WHEN Revenue = 0 THEN 1 ELSE 0 END) AS Zero_Revenue,
    MIN(UnitsSold) AS Minimum_UnitsSold,
    MAX(UnitsSold) AS Maximum_UnitsSold,
    SUM(CASE WHEN UnitsSold < 0 THEN 1 ELSE 0 END) AS Negative_UnitsSold,
    SUM(CASE WHEN UnitsSold = 0 THEN 1 ELSE 0 END) AS Zero_UnitsSold
FROM retail_sales_master;

-- ==========================================
-- 8. OVERALL BUSINESS KPIs
-- Calculate total orders, units sold, revenue,
-- profit and average order metrics
-- ==========================================
SELECT
    COUNT(*) AS Total_Orders,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(EstimatedProfit) AS Total_Estimated_Profit,
    AVG(Revenue) AS Average_Revenue_Per_Order,
    AVG(UnitsSold) AS Average_Units_Per_Order
FROM retail_sales_master;

-- ==========================================
-- 9. PROFIT COLUMN VALIDATION
-- Verify available profit-related columns
-- ==========================================
SHOW COLUMNS FROM retail_sales_master
LIKE '%Profit%';

-- ==========================================
-- 10. OVERALL BUSINESS KPIs
-- Calculate total orders, units sold, revenue,
-- profit and average order metrics
-- ==========================================
SELECT
    COUNT(*) AS Total_Orders,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Profit) AS Total_Estimated_Profit,
    AVG(Revenue) AS Average_Revenue_Per_Order,
    AVG(UnitsSold) AS Average_Units_Per_Order
FROM retail_sales_master;

-- ==========================================
-- 11. PRODUCT CATEGORY ANALYSIS
-- Analyze orders, units sold, revenue,
-- profit and profit margin by category
-- ==========================================
SELECT
    ProductCategory,
    COUNT(*) AS Total_Orders,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Profit) AS Total_Profit,
    AVG(Profit_Margin_Percent) AS Avg_Profit_Margin
FROM retail_sales_master
GROUP BY ProductCategory
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 12. OCCASION-WISE ANALYSIS
-- Analyze sales performance by occasion
-- ==========================================
SELECT
    Occasion,
    COUNT(*) AS Total_Orders,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Profit) AS Total_Profit
FROM retail_sales_master
GROUP BY Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 13. REGION-WISE ANALYSIS
-- Analyze sales performance across regions
-- ==========================================
SELECT
    Region,
    COUNT(*) AS Total_Orders,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Profit) AS Total_Profit
FROM retail_sales_master
GROUP BY Region
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 14. MONTHLY SALES TREND
-- Analyze monthly orders, units sold,
-- revenue and profit
-- ==========================================
SELECT
    DATE_FORMAT(STR_TO_DATE(SaleDate, '%Y-%m-%d'), '%Y-%m') AS Sales_Month,
    COUNT(*) AS Total_Orders,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Profit) AS Total_Profit
FROM retail_sales_master
GROUP BY Sales_Month
ORDER BY Sales_Month;


-- ==========================================
-- 15. PRODUCT-WISE ANALYSIS
-- Analyze orders, units sold, revenue,
-- profit and average unit cost by product
-- ==========================================
SELECT
    Productid,
    COUNT(*) AS Total_Orders,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Profit) AS Total_Profit,
    AVG(Weighted_Average_Cost) AS Avg_Unit_Cost
FROM retail_sales_master
GROUP BY Productid
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16. EXECUTIVE SUMMARY
-- Summarize key dataset and business metrics
-- ==========================================
SELECT
    COUNT(*) AS Total_Records,
    COUNT(DISTINCT OrderId) AS Unique_Orders,
    COUNT(DISTINCT Productid) AS Unique_Products,
    COUNT(DISTINCT ProductCategory) AS Categories,
    COUNT(DISTINCT Occasion) AS Occasions,
    COUNT(DISTINCT Region) AS Regions,
    SUM(UnitsSold) AS Total_Units_Sold,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Profit) AS Total_Profit,
    ROUND(AVG(Revenue), 2) AS Avg_Revenue_Per_Record
FROM retail_sales_master;

-- 16.1 HIGHEST REVENUE CATEGORY
-- Identify the product category generating the highest revenue

SELECT
    ProductCategory,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY ProductCategory
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.2 HIGHEST REVENUE OCCASION
-- Identify the occasion generating the highest revenue
-- ==========================================
SELECT
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.3 HIGHEST REVENUE REGION
-- Identify the region generating the highest revenue
-- ==========================================
SELECT
    Region,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Region
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.4 HIGHEST REVENUE PRODUCT
-- Identify the product generating the highest revenue
-- ==========================================
SELECT
    ProductId,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY ProductId
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.5 HIGHEST REVENUE STORE
-- Identify the store generating the highest revenue
-- ==========================================
SELECT
    Store,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Store
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.6 HIGHEST REVENUE MATERIAL
-- Identify the material generating the highest revenue
-- ==========================================
SELECT
    Material,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Material
ORDER BY Total_Revenue DESC;


-- ==========================================
-- 16.7 HIGHEST REVENUE YEAR
-- Identify the year generating the highest revenue
-- ==========================================
SELECT
    YEAR(STR_TO_DATE(SaleDate, '%Y-%m-%d')) AS Sales_Year,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Sales_Year
ORDER BY Total_Revenue DESC;

SELECT
    YEAR(STR_TO_DATE(SaleDate, '%Y-%m-%d')) AS Sales_Year,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Sales_Year
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.8 HIGHEST REVENUE MONTH
-- Identify the month generating the highest revenue
-- ==========================================
SELECT
    DATE_FORMAT(
        STR_TO_DATE(SaleDate, '%Y-%m-%d'),
        '%Y-%m'
    ) AS Sales_Month,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Sales_Month
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.9 HIGHEST REVENUE CATEGORY + OCCASION
-- Identify the category and occasion combination
-- generating the highest revenue
-- ==========================================
SELECT
    ProductCategory,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY ProductCategory, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.10 HIGHEST REVENUE REGION + CATEGORY
-- Identify the region and product category
-- combination generating the highest revenue
-- ==========================================
SELECT
    Region,
    ProductCategory,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Region, ProductCategory
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.11 HIGHEST REVENUE STORE + CATEGORY
-- Identify the store and product category
-- combination generating the highest revenue
-- ==========================================
SELECT
    Store,
    ProductCategory,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Store, ProductCategory
ORDER BY Total_Revenue DESC;


-- ==========================================
-- 16.12 HIGHEST REVENUE STORE + OCCASION
-- Identify the store and occasion combination
-- generating the highest revenue
-- ==========================================
SELECT
    Store,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Store, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.13 HIGHEST REVENUE REGION + OCCASION
-- Identify the region and occasion combination
-- generating the highest revenue
-- ==========================================
SELECT
    Region,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Region, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.14 HIGHEST REVENUE REGION + PRODUCT + OCCASION
-- Identify the region, product category and occasion
-- combination generating the highest revenue
-- ==========================================
SELECT
    Region,
    ProductCategory,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Region, ProductCategory, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.15 HIGHEST REVENUE STORE + REGION + CATEGORY
-- Identify the store, region and product category
-- combination generating the highest revenue
-- =========================================
SELECT
    Store,
    Region,
    ProductCategory,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Store, Region, ProductCategory
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.16 HIGHEST REVENUE STORE + REGION + OCCASION
-- Identify the store, region and occasion
-- combination generating the highest revenue
-- ==========================================
SELECT
    Store,
    Region,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Store, Region, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.17 HIGHEST REVENUE YEAR
-- Identify the year generating the highest revenue
-- ==========================================
SELECT
    YEAR(STR_TO_DATE(SaleDate, '%Y-%m-%d')) AS Sales_Year,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Sales_Year
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.18 HIGHEST REVENUE MONTH
-- Identify the month generating the highest revenue
-- ==========================================
SELECT
    DATE_FORMAT(
        STR_TO_DATE(SaleDate, '%Y-%m-%d'),
        '%Y-%m'
    ) AS Sales_Month,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Sales_Month
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.19 HIGHEST REVENUE CATEGORY + OCCASION
-- Identify the category and occasion combination
-- generating the highest revenue
-- ==========================================
SELECT
    ProductCategory,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY ProductCategory, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.20 HIGHEST REVENUE REGION + CATEGORY
-- Identify the region and product category
-- combination generating the highest revenue
-- ==========================================
SELECT
    Region,
    ProductCategory,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Region, ProductCategory
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.21 HIGHEST REVENUE STORE + CATEGORY
-- Identify the store and product category
-- combination generating the highest revenue
-- ==========================================
SELECT
    Store,
    ProductCategory,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Store, ProductCategory
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.22 HIGHEST REVENUE STORE + OCCASION
-- Identify the store and occasion
-- combination generating the highest revenue
-- ==========================================
SELECT
    Store,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Store, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.23 HIGHEST REVENUE REGION + OCCASION
-- Identify the region and occasion
-- combination generating the highest revenue
-- ==========================================
SELECT
    Region,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Region, Occasion
ORDER BY Total_Revenue DESC;

-- ==========================================
-- 16.24 HIGHEST REVENUE REGION + PRODUCT CATEGORY + OCCASION
-- Identify the region, product category and occasion
-- combination generating the highest revenue
-- ==========================================
SELECT
    Region,
    ProductCategory,
    Occasion,
    SUM(Revenue) AS Total_Revenue
FROM retail_sales_master
GROUP BY Region, ProductCategory, Occasion
ORDER BY Total_Revenue DESC;


-- ==========================================
-- 16.25 PROFIT MARGIN BY CATEGORY & MATERIAL
-- Identify profitability across product categories
-- and material/sub-category
-- ==========================================
SELECT
    ProductCategory,
    Material,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Cost) AS Total_Cost,
    SUM(Estimated_Profit) AS Total_Profit,
    ROUND(
        (SUM(Estimated_Profit) / NULLIF(SUM(Revenue), 0)) * 100,
        2
    ) AS Profit_Margin_Percentage
FROM retail_sales_master
GROUP BY ProductCategory, Material
ORDER BY Profit_Margin_Percentage DESC;

-- ==========================================
-- 16.26 PROFIT MARGIN BY PRODUCT CATEGORY
-- ==========================================

SELECT
    ProductCategory,
    SUM(Revenue) AS Total_Revenue,
    SUM(Estimated_Cost) AS Total_Cost,
    SUM(Estimated_Profit) AS Total_Profit,
    ROUND(
        (SUM(Estimated_Profit) / NULLIF(SUM(Revenue), 0)) * 100,
        2
    ) AS Profit_Margin_Percentage
FROM retail_sales_master
GROUP BY ProductCategory
ORDER BY Profit_Margin_Percentage DESC;